import React, { useState } from "react";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from '@react-navigation/stack';
import { View, Text, TextInput, Button, ScrollView, StyleSheet, FlatList, Image } from "react-native";
import { Ionicons, FontAwesome5 } from '@expo/vector-icons';

const tabs = createBottomTabNavigator();
const Stack = createStackNavigator();

// Data barang dan fungsi untuk mengelolanya
const initialItems = [
  { id: '1', name: 'Barang 1' },
  { id: '2', name: 'Barang 2' },
];

const HomeScreen = ({ items }) => (
  <ScrollView contentContainerStyle={styles.container}>
    <FlatList
      data={items}
      keyExtractor={item => item.id}
      renderItem={({ item }) => (
        <View style={styles.item}>
          <Text>{item.name}</Text>
        </View>
      )}
    />
  </ScrollView>
);

const SecondScreen = ({ items, addItem, removeItem }) => {
  const [newItemName, setNewItemName] = useState('');

  const handleAddItem = () => {
    if (newItemName.trim()) {
      addItem(newItemName);
      setNewItemName('');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Nama Barang"
        value={newItemName}
        onChangeText={setNewItemName}
      />
      <Button title="Tambahkan Barang" onPress={handleAddItem} />
      <FlatList
        data={items}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text>{item.name}</Text>
            <Button title="Hapus" onPress={() => removeItem(item.id)} />
          </View>
        )}
      />
    </ScrollView>
  );
};

const ProfileScreen = () => (
  <View style={styles.profileContainer}>
    <Image
      source={{ uri: 'https://via.placeholder.com/150' }} // Ganti URL dengan URL gambar profil sebenarnya
      style={styles.profileImage}
    />
    <Text style={styles.profileName}>KUKUH</Text>
  </View>
);

const MainNavigator = ({ items, addItem, removeItem }) => {
  return (
    <tabs.Navigator>
      <tabs.Screen 
        name="Home"
        children={() => <HomeScreen items={items} />}
        options={{
          tabBarIcon: ({color, size}) =>(
            <FontAwesome5 name= "home" color="black" size={25}/>
          ),
        }}
      />
      <tabs.Screen 
        name="Second"
        children={() => <SecondScreen items={items} addItem={addItem} removeItem={removeItem} />}
        options={{
          tabBarIcon: ({color, size}) =>(
            <FontAwesome5 name= "folder" color="black" size={25}/>
          ),
        }}
      />
      <tabs.Screen 
        name="Profile"
        component={ProfileScreen}
        options={{
          tabBarIcon: ({color, size}) =>(
            <FontAwesome5 name= "user" color="black" size={25}/>
          ),
        }}
      />
    </tabs.Navigator>
  );
};

const LoginScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (username === 'KUKUH' && password === 'Test123') {
      navigation.replace('Main');
    } else {
      alert('Username atau Password salah');
    }
  };

  return (
    <View style={styles.loginContainer}>
      <Text style={styles.loginTitle}>Login</Text>
      <TextInput
        style={styles.input}
        placeholder="Username"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <Button title="Login" onPress={handleLogin} />
    </View>
  );
};

export default function App() {
  const [items, setItems] = useState(initialItems);

  const addItem = (name) => {
    setItems([...items, { id: Math.random().toString(), name }]);
  };

  const removeItem = (id) => {
    setItems(items.filter(item => item.id !== id));
  };

  return(
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Main">
          {() => <MainNavigator items={items} addItem={addItem} removeItem={removeItem} />}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 20,
  },
  loginContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loginTitle: {
    fontSize: 24,
    marginBottom: 20,
  },
  input: {
    width: '100%',
    padding: 10,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
  },
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    borderBottomWidth: 1,
    borderColor: '#ccc',
  },
  profileContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileImage: {
    width: 150,
    height: 150,
    borderRadius: 75,
  },
  profileName: {
    marginTop: 20,
    fontSize: 24,
  },
});
